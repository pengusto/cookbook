# Cookbook banner — local review, 2026-10-23

Local draft only. No commit, push, PR, release, deployment or GitHub metadata change was performed for this round. The maintained READMEs, original logo masters, existing illustrations and runtime sources were not changed by this banner work.

## Files

- `../../assets/readme/cookbook-banner-purple-v1.png`: 2172 × 724 PNG, exactly 3:1; new AI illustration.
- `README.preview.md`, `README.preview.de.md`: EN/DE README drafts with the banner replacing the opening logo block in the preview only. Remaining content is copied from the maintained READMEs with relative links adjusted.
- `README.preview.html`, `README.preview.de.html`: local GFM renderings for review.
- `desktop.png`, `mobile-390.png`, `mobile-390-dark.png`, `mobile-390-de.png`: local browser captures.
- `viewport-check.json`: measured browser dimensions and image loading checks.
- `prompt.txt`, `provenance.json`: full generation prompt, reference roles and asset checksum. The built-in image tool received both actual reference images.
- `../../THIRD_PARTY_NOTICES.md`: appended provenance and retained rights limitations.

## Review

The reference penguin, plum/lavender palette, open recipe book, workflow cards and cream Cookbook identity remain recognisable. The rendered wordmark in the illustration is generated artwork; the original vector logo remains authoritative and unchanged. This is an illustration, not an application screenshot or a new product capability.

Desktop checked at 1280 px; EN checked at 390 px in light/dark and DE at 390 px in light. The banner scales naturally to about 358 × 119 px on mobile. No image cropping, broken images or page-wide horizontal overflow was observed. Penguin, open book and card symbols remain distinguishable; the small byline is secondary, with the full project name also present as a native README heading.

The drafts use a standard Markdown image with descriptive alt text. They do not require picture switching, overlays, JavaScript or custom product CSS on GitHub. The local HTML uses Marked GFM and approximate GitHub-style typography for inspection; it is not a capture of a published GitHub README. GitHub's exact rendering has not been tested or published in this round. Existing external badge URLs remain as in the source README.

The original generated file remains in the image tool's output directory; the project copy is self-contained. Temporary rendering helper removed after verification. No original asset was deleted or overwritten.

## Kitchen revision v2

Maintainer feedback: v1 read too much as a workbench and too little as a kitchen. The v2 prompt makes the kitchen the dominant setting: stove/oven, steaming copper pot, hanging utensils, preparation board, herbs and cream cabinetry. Keep the workflow cards and open cookbook to connect the cooking metaphor to the project. This is the composition lesson for further Cookbook illustration work.

New sibling asset: `../../assets/readme/cookbook-banner-purple-kitchen-v2.png`. EN/DE Markdown and HTML previews use the `README.kitchen-v2` prefix; measured captures and checks use `kitchen-v2-` / `viewport-check-kitchen-v2.json`. Both versions remain available. Desktop 1280 px and mobile 390 px (EN light/dark, DE light) were rendered and checked with no broken images, cropping or page overflow. Existing README sources remain unchanged; this revision is local and unpublished.

## Maintainer selection and local integration

The maintainer approved kitchen v2 and requested integration into all existing README languages without committing or pushing. The opening logo block is now replaced by the same kitchen banner in all eight maintained READMEs, each with localized alt text and a repository-relative image path. Original logo masters and both banner versions remain intact. Earlier statements about unchanged README sources describe the preview-only stage. No commit or publication performed.

## Freer alternative v3

Updated maintainer guidance: the profile image is a character reference, not a fixed scene template. A freestanding illustrated kitchen grows from a giant open cookbook, using the existing cream, wine-red, sage and copper brand palette with small lavender tabs. No island or night-water setting. Preserve v1/v2 and the selected v2 integration. The new `README.storybook-v3` previews are alternatives only, pending a choice in this chat. Lesson: separate character invariants from scene, palette and composition in future prompts.

V3 checked at 1280 px and 390 px (EN light/dark, DE light): no page overflow, broken images or cropping. Native Markdown image scaling; local HTML remains a GFM approximation, not published GitHub acceptance. All eight maintained READMEs still use the user-selected kitchen v2.

## Final local selection: storybook v3

The maintainer prefers cream and wine red. All eight maintained README languages now reference storybook v3 with localized alt text, superseding the earlier v2 integration. Original assets, old variants and their preview captures are retained. Theme-specific or transparent variants have not been generated or integrated; those were discussed as options. No commit or push.

## Theme pair and small-screen verification

The maintainer requested matching light/dark variants. The selected v3 remains the light asset; `cookbook-banner-storybook-dark.png` is an AI-edited companion preserving the composition, character and project colours. All eight maintained READMEs use native `picture` with dark/light `source` entries and a descriptive localized `img` fallback to light. No CSS-only swap, no transparency and no automation.

EN and DE local GFM previews were rendered at 1280, 390 and 320 px in both themes (12 combinations). `viewport-check-themes.json` confirms the actual currentSrc, no broken images and no page overflow. At 320 px the full banner is about 288 × 96 px: title, penguin, copper pot and open-book/kitchen shape remain identifiable; small byline and decorative details are secondary. Native README heading and alt text supply the full accessible name. No separate mobile crop is needed to understand this composition. Captures use `themes-` prefix; review entry is `README.themes.html`. This is local browser verification, not a capture of GitHub’s live renderer. All former variants remain retained; no commit or push.

## Authorized publication and closure

The maintainer subsequently authorized push and merge if needed. The remote website-discovery fix was fast-forwarded first; no open PR required a merge. Commit `7d2f54906115134368c01d6851ff26ad56c1c44a` publishes only the eight READMEs, selected light/dark images, `assets/readme/SOURCES.json` and the updated third-party notice. Exact staged-tree launch audit passed with 35 tests and identical portable artifacts, excluding pre-existing local skill/catalog changes. Remote main matches the commit; Cookbook checks run 39952747401 and publication run 39952747561 both succeeded. Earlier drafts and local viewport captures remain retained here for provenance and comparison, not included in the commit. Pre-existing skill/catalog edits remain uncommitted and untouched.
